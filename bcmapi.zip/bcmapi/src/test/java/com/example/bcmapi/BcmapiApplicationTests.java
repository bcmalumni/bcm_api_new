package com.example.bcmapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BcmapiApplicationTests {

	@Test
	void contextLoads() {
	}

}
