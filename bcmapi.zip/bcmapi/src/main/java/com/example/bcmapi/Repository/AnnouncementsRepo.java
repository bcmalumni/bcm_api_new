package com.example.bcmapi.Repository;

import com.example.bcmapi.Entity.Announcements;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import org.springframework.web.bind.annotation.RestController;

@Repository
public interface AnnouncementsRepo extends JpaRepository<Announcements,Integer> {
}
