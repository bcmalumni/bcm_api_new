package com.example.bcmapi.Controller;

import com.example.bcmapi.DTO.LoginDTO;
import com.example.bcmapi.Repository.AdminRepo;
import com.example.bcmapi.Repository.UsersRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
@CrossOrigin("*")
public class LoginController {

    @Autowired
    private AdminRepo adminRepo;

    @Autowired
    private UsersRepo usersRepo;

    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody LoginDTO obj) {
        if ("bcmha2024000001".equals(obj.getId())) {
            var admin = adminRepo.findById(obj.getId())
                    .orElseThrow(() -> new RuntimeException("Admin not found"));
            if (admin.getPassword().equals(obj.getPassword())) {
                return new ResponseEntity<>(admin, HttpStatus.OK);
            } else {
                return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Invalid password");
            }
        } else {
            var user = usersRepo.findById(obj.getId())
                    .orElseThrow(() -> new RuntimeException("User not found"));
            if ("pending".equals(user.getStatus())) {
              if (user.getPassword().equals(obj.getPassword())) {
                return new ResponseEntity<>(user, HttpStatus.OK);
            } else {
                return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Invalid password");
            }}
            else {
                return ResponseEntity.status(HttpStatus.FORBIDDEN).body("User is blocked");
            }
        }
    }
}
