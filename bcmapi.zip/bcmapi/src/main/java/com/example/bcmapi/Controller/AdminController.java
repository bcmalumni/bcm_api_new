package com.example.bcmapi.Controller;

import com.example.bcmapi.Entity.Admin;
import com.example.bcmapi.Repository.AdminRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin("*")
public class AdminController {
    @Autowired
    private AdminRepo adminRepo;

    @GetMapping("getadmin")
    public ResponseEntity<?> getadmin(){
        List<Admin> use = adminRepo.findAll();
        return new ResponseEntity<>(use, HttpStatus.OK);
    }

    @PostMapping("postadmin")
    public ResponseEntity<?> postadmin(@RequestBody Admin obj){
        Admin use = adminRepo.save(obj);
        return new ResponseEntity<>(use,HttpStatus.OK);
    }

    @PutMapping("putadmin")
    public ResponseEntity<?> putadmin(@RequestBody Admin obj){
        Admin use = adminRepo.save(obj);
        return new ResponseEntity<>(use,HttpStatus.OK);
    }
}
