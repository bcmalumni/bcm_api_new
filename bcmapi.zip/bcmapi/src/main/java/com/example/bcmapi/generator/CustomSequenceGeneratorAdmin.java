package com.example.bcmapi.generator;

import org.hibernate.engine.spi.SharedSessionContractImplementor;
import org.hibernate.id.IdentifierGenerator;

import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.concurrent.atomic.AtomicInteger;

public class CustomSequenceGeneratorAdmin implements IdentifierGenerator {

    private static final String PREFIX = "bcmha";
    private static final AtomicInteger COUNTER = new AtomicInteger(1);

    public CustomSequenceGeneratorAdmin() {
        // Default constructor
        System.out.println("CustomSequenceGeneratorAdmin instantiated");
    }

    @Override
    public Serializable generate(SharedSessionContractImplementor session, Object object) {
        String date = new SimpleDateFormat("yyyy").format(new Date());
        String generatedId = PREFIX + date + String.format("%06d", COUNTER.getAndIncrement());
        System.out.println("Generated ID: " + generatedId);
        return generatedId;
    }
}
