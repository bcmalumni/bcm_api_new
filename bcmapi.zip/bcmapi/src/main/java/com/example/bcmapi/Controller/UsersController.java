package com.example.bcmapi.Controller;

import com.example.bcmapi.Entity.EmailService;
import com.example.bcmapi.Entity.Gallery;
import com.example.bcmapi.Entity.Users;
import com.example.bcmapi.Repository.UsersRepo;
import jakarta.persistence.Entity;

import org.apache.catalina.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin("*")
public class UsersController {
    @Autowired
    private UsersRepo usersRepo;

    @GetMapping("getusers")
    public ResponseEntity<?> getusers(){
        List<Users> use = usersRepo.findAll();
        return new ResponseEntity<>(use, HttpStatus.OK);
    }

//    @PostMapping("postusers")
//    public ResponseEntity<?> postusers(@RequestBody Users obj){
//        Users use = usersRepo.save(obj);
//        return new ResponseEntity<>(use,HttpStatus.OK);
//    }

    @PutMapping("putusers")
    public ResponseEntity<?> putusers(@RequestBody Users obj){
        Users use = usersRepo.save(obj);
        return new ResponseEntity<>(use,HttpStatus.OK);
    }

    @PutMapping("/updateUserStatus/{id}/{status}")
    public ResponseEntity<?> updateUserStatus(@PathVariable String id, @PathVariable String status) {
        int rowsUpdated = usersRepo.updateUserStatus(id, status);
        if (rowsUpdated > 0) {
            return new ResponseEntity<>(HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }
    
    @Autowired
    private EmailService emailService;

    @PostMapping("postusers")
    public ResponseEntity<?> registerUser(@RequestBody Users user) {

    	usersRepo.save(user);

        String to = "bcmhostelalumni@gmail.com";
        String subject = "New User Registration";
        String text = "A new user has registered. Please review and approve the registration. Details: \n"
                      + "Name: " + user.getName() + "\n"
                      + "Date of Birth: " + user.getDob() + "\n"
                      + "Transaction Id: " + user.getTransactionId() + "\n"
                      + "Mobile No: " + user.getPhone();
        emailService.sendRegistrationEmail(to, subject, text);

        return ResponseEntity.ok(user);
    }
    
    
    
}
