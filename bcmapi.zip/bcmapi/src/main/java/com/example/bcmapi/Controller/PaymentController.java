package com.example.bcmapi.Controller;


import org.json.JSONObject;
import org.springframework.web.bind.annotation.*;
import com.razorpay.*;
import java.util.Map;

@RestController
@CrossOrigin("*")
public class PaymentController {

    @PostMapping("createpayment")
    @ResponseBody
    public String createOrder(@RequestBody Map<String, Object> data) throws RazorpayException {

        System.out.println(data);
        int amt = Integer.parseInt(data.get("amount").toString());
        var client= new RazorpayClient("rzp_test_1oM51M2uaRuyGI","wr0PNRVFATz6yPMatg60NAHL");

        JSONObject ob =new JSONObject();
        ob.put("amount",amt*100);
        ob.put("currency","INR");
        ob.put("receipt","txn_235425");

        Order order = client.orders.create(ob);
        return order.toString();
    }
}
