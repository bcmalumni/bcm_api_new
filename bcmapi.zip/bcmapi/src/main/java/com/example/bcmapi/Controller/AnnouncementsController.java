package com.example.bcmapi.Controller;

import com.example.bcmapi.Entity.Admin;
import com.example.bcmapi.Entity.Announcements;
import com.example.bcmapi.Repository.AnnouncementsRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin("*")
public class AnnouncementsController {
    @Autowired
    private AnnouncementsRepo announcementsRepo;

    @GetMapping("getannouncements")
    public ResponseEntity<?> getadmin(){
        List<Announcements> use = announcementsRepo.findAll();
        return new ResponseEntity<>(use, HttpStatus.OK);
    }

    @PostMapping("postannouncements")
    public ResponseEntity<?> postannouncements(@RequestBody Announcements obj){
        Announcements use = announcementsRepo.save(obj);
        return new ResponseEntity<>(use,HttpStatus.OK);
    }

    @PutMapping("putannouncements")
    public ResponseEntity<?> putannouncements(@RequestBody Announcements obj){
        Announcements use = announcementsRepo.save(obj);
        return new ResponseEntity<>(use,HttpStatus.OK);
    }

    @DeleteMapping("deleteannouncments/{id}")
    public ResponseEntity<?> deletegallery(@PathVariable int id){
        announcementsRepo.deleteById(id);
        return new ResponseEntity<>(HttpStatus.OK);
    }
}
