package com.example.bcmapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BcmapiApplication {

	public static void main(String[] args) {
		SpringApplication.run(BcmapiApplication.class, args);
	}

}
