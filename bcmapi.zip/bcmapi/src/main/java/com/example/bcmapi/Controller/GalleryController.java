package com.example.bcmapi.Controller;

import com.example.bcmapi.Entity.Announcements;
import com.example.bcmapi.Entity.Gallery;
import com.example.bcmapi.Repository.GalleryRepo;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin("*")
public class GalleryController {
    @Autowired
    private GalleryRepo galleryRepo;

    @GetMapping("getgallery")
    public ResponseEntity<?> getgallery(){
        List<Gallery> use = galleryRepo.findAll();
        return new ResponseEntity<>(use, HttpStatus.OK);
    }

    @PostMapping("postgallery")
    public ResponseEntity<?> postgallery(@RequestBody Gallery obj){
        Gallery use = galleryRepo.save(obj);
        return new ResponseEntity<>(use,HttpStatus.OK);
    }

    @PutMapping("putgallery")
    public ResponseEntity<?> putgallery(@RequestBody Gallery obj){
        Gallery use = galleryRepo.save(obj);
        return new ResponseEntity<>(use,HttpStatus.OK);
    }

    @DeleteMapping("deletegallery/{id}")
    public ResponseEntity<?> deletegallery(@PathVariable int id){
        galleryRepo.deleteById(id);
        return new ResponseEntity<>(HttpStatus.OK);
    }
}
